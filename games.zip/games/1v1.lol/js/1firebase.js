function initializeFireBase(){
	// Your web app's Firebase configuration
	var firebaseConfig = {
	apiKey: "AIzaSyBPrAfspM9RFxuNuDtSyaOZ5YRjDBNiq5I",
	authDomain: "justbuild-cdb86.firebaseapp.com",
	databaseURL: "https://justbuild-cdb86.firebaseio.com",
	projectId: "justbuild-cdb86",
	storageBucket: "justbuild-cdb86.appspot.com",
	messagingSenderId: "93158914000",
	appId: "1:93158914000:web:e73a8b453338ab7c"
	};
	// Initialize Firebase
	firebase.initializeApp(firebaseConfig);
}